// StudyVerse website search
const searchBox = document.getElementById("search");
const searchableItems = document.querySelectorAll(".searchable");

if (searchBox) {
  searchBox.addEventListener("input", function () {
    const query = this.value.trim().toLowerCase();

    searchableItems.forEach(function (item) {
      const text = item.innerText.toLowerCase();
      item.classList.toggle("hidden", query !== "" && !text.includes(query));
    });
  });
}
